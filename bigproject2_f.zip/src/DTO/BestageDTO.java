package DTO;

public class BestageDTO {
	int prank;
	String isbn;
	String name;
	String age;
	
	public int getPrank() {
		return prank;
	}
	public void setPrank(int prank) {
		this.prank = prank;
	}
	public String getIsbn() {
		return isbn;
	}
	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAge() {
		return age;
	}
	public void setAge(String age) {
		this.age = age;
	}
	
	
}
