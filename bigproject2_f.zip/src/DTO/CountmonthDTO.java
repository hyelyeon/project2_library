package DTO;

public class CountmonthDTO {
	String isbn;
	String name;
	int m09;
	int m10;
	int m11;
	int m12;
	int m01;
	int m02;
	int m03;
	int m04;
	int m05;
	int m06;
	int m07;
	int m08;
	
	public String getIsbn() {
		return isbn;
	}
	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getM09() {
		return m09;
	}
	public void setM09(int m09) {
		this.m09 = m09;
	}
	public int getM10() {
		return m10;
	}
	public void setM10(int m10) {
		this.m10 = m10;
	}
	public int getM11() {
		return m11;
	}
	public void setM11(int m11) {
		this.m11 = m11;
	}
	public int getM12() {
		return m12;
	}
	public void setM12(int m12) {
		this.m12 = m12;
	}
	public int getM01() {
		return m01;
	}
	public void setM01(int m01) {
		this.m01 = m01;
	}
	public int getM02() {
		return m02;
	}
	public void setM02(int m02) {
		this.m02 = m02;
	}
	public int getM03() {
		return m03;
	}
	public void setM03(int m03) {
		this.m03 = m03;
	}
	public int getM04() {
		return m04;
	}
	public void setM04(int m04) {
		this.m04 = m04;
	}
	public int getM05() {
		return m05;
	}
	public void setM05(int m05) {
		this.m05 = m05;
	}
	public int getM06() {
		return m06;
	}
	public void setM06(int m06) {
		this.m06 = m06;
	}
	public int getM07() {
		return m07;
	}
	public void setM07(int m07) {
		this.m07 = m07;
	}
	public int getM08() {
		return m08;
	}
	public void setM08(int m08) {
		this.m08 = m08;
	}
	
	
	
}
