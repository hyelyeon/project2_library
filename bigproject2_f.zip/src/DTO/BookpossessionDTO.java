package DTO;

public class BookpossessionDTO {
	String isbn;	
	String name;	
	int nonhyeon;
	int daechi;
	int dogog;
	int mosgol;
	int hanog;
	int yeogsam;
	int puleunsol;
	int jeongdaun;
	int jeulgeoun;
	int cheongdam;
	int haengboghan;
	int gangnam;
	int gaepo;
	
	public String getIsbn() {
		return isbn;
	}
	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getNonhyeon() {
		return nonhyeon;
	}
	public void setNonhyeon(int nonhyeon) {
		this.nonhyeon = nonhyeon;
	}
	public int getDaechi() {
		return daechi;
	}
	public void setDaechi(int daechi) {
		this.daechi = daechi;
	}
	public int getDogog() {
		return dogog;
	}
	public void setDogog(int dogog) {
		this.dogog = dogog;
	}
	public int getMosgol() {
		return mosgol;
	}
	public void setMosgol(int mosgol) {
		this.mosgol = mosgol;
	}
	public int getHanog() {
		return hanog;
	}
	public void setHanog(int hanog) {
		this.hanog = hanog;
	}
	public int getYeogsam() {
		return yeogsam;
	}
	public void setYeogsam(int yeogsam) {
		this.yeogsam = yeogsam;
	}
	public int getPuleunsol() {
		return puleunsol;
	}
	public void setPuleunsol(int puleunsol) {
		this.puleunsol = puleunsol;
	}
	public int getJeongdaun() {
		return jeongdaun;
	}
	public void setJeongdaun(int jeongdaun) {
		this.jeongdaun = jeongdaun;
	}
	public int getJeulgeoun() {
		return jeulgeoun;
	}
	public void setJeulgeoun(int jeulgeoun) {
		this.jeulgeoun = jeulgeoun;
	}
	public int getCheongdam() {
		return cheongdam;
	}
	public void setCheongdam(int cheongdam) {
		this.cheongdam = cheongdam;
	}
	public int getHaengboghan() {
		return haengboghan;
	}
	public void setHaengboghan(int haengboghan) {
		this.haengboghan = haengboghan;
	}
	public int getGangnam() {
		return gangnam;
	}
	public void setGangnam(int gangnam) {
		this.gangnam = gangnam;
	}
	public int getGaepo() {
		return gaepo;
	}
	public void setGaepo(int gaepo) {
		this.gaepo = gaepo;
	} 
	
	
	
}
