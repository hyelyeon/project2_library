package DTO;

public class BesttotalDTO {
	int prank;
	String isbn;
	String name;
	
	public int getPrank() {
		return prank;
	}
	public void setPrank(int prank) {
		this.prank = prank;
	}
	public String getIsbn() {
		return isbn;
	}
	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
}
