// 성별 라디오 박스 체크 및 해제
$(function(){
    $("#sex1").on('click', function() {
        $(".sex1").attr("checked",false);
        $(".sexlabel").removeClass("active");
        $("#sexlabel1").addClass("active");
        $("#sex1").attr("checked", true);
    });

    $("#sex2").on('click', function() {
        $(".sex2").attr("checked",false);
        $(".sexlabel").removeClass("active");
        $("#sexlabel2").addClass("active");
        $("#sex2").attr("checked", true);
    });

    $("#sex3").on('click', function() {
        $(".sex3").attr("checked",false);
        $(".sexlabel").removeClass("active");
        $("#sexlabel3").addClass("active");
        $("#sex3").attr("checked", true);
    });
});

// 연령 체크 박스 체크 및 해제
$(function(){
    $("#age1").on('click', function() {
        $(".age").attr("checked",false);
        $(".agelabel").removeClass("active");
        $("#agelabel1").addClass("active");
        $("#age1").attr("checked", true);
    });

    $("#age2").on('click', function() {
        $(".age").attr("checked",false);
        $(".agelabel").removeClass("active");
        $("#agelabel2").addClass("active");
        $("#age2").attr("checked", true);
    });

    $("#age3").on('click', function() {
    	$(".age").attr("checked",false);
        $(".agelabel").removeClass("active");
        $("#agelabel3").addClass("active");
        $("#age3").attr("checked", true);
    });

    $("#age4").on('click', function() {
    	$(".age").attr("checked",false);
        $(".agelabel").removeClass("active");
        $("#agelabel4").addClass("active");
        $("#age4").attr("checked", true);
    });

    $("#age5").on('click', function() {
    	$(".age").attr("checked",false);
        $(".agelabel").removeClass("active");
        $("#agelabel5").addClass("active");
        $("#age5").attr("checked", true);
    });

    $("#age6").on('click', function() {
    	$(".age").attr("checked",false);
        $(".agelabel").removeClass("active");
        $("#agelabel6").addClass("active");
        $("#age6").attr("checked", true);
    });

    $("#age7").on('click', function() {
    	$(".age").attr("checked",false);
        $(".agelabel").removeClass("active");
        $("#agelabel7").addClass("active");
        $("#age7").attr("checked", true);
    });

    $("#age8").on('click', function() {
    	$(".age").attr("checked",false);
        $(".agelabel").removeClass("active");
        $("#agelabel8").addClass("active");
        $("#age8").attr("checked", true);
    });

    $("#age9").on('click', function() {
    	$(".age").attr("checked",false);
        $(".agelabel").removeClass("active");
        $("#agelabel9").addClass("active");
        $("#age9").attr("checked", true);
    });

    $("#age10").on('click', function() {
    	$(".age").attr("checked",false);
        $(".agelabel").removeClass("active");
        $("#agelabel10").addClass("active");
        $("#age10").attr("checked", true);
    });
});

// 주제 체크 박스 체크 및 해제
$(function(){
    $("#thema1").on('click', function() {
        $(".thema").attr("checked",false);
        $(".themalabel").removeClass("active");
        $("#themalabel1").addClass("active");
        $("#thema1").attr("checked", true);
    });

    $("#thema2").on('click', function() {
    	$(".thema").attr("checked",false);
        $(".themalabel").removeClass("active");
        $("#themalabel2").addClass("active");
        $("#thema2").attr("checked", true);
    });

    $("#thema3").on('click', function() {
    	$(".thema").attr("checked",false);
        $(".themalabel").removeClass("active");
        $("#themalabel3").addClass("active");
        $("#thema3").attr("checked", true);
    });

    $("#thema4").on('click', function() {
    	$(".thema").attr("checked",false);
        $(".themalabel").removeClass("active");
        $("#themalabel4").addClass("active");
        $("#thema4").attr("checked", true);
    });

    $("#thema5").on('click', function() {
    	$(".thema").attr("checked",false);
        $(".themalabel").removeClass("active");
        $("#themalabel5").addClass("active");
        $("#thema5").attr("checked", true);
    });

    $("#thema6").on('click', function() {
    	$(".thema").attr("checked",false);
        $(".themalabel").removeClass("active");
        $("#themalabel6").addClass("active");
        $("#thema6").attr("checked", true);
    });

    $("#thema7").on('click', function() {
    	$(".thema").attr("checked",false);
        $(".themalabel").removeClass("active");
        $("#themalabel7").addClass("active");
        $("#thema7").attr("checked", true);
    });

    $("#thema8").on('click', function() {
    	$(".thema").attr("checked",false);
        $(".themalabel").removeClass("active");
        $("#themalabel8").addClass("active");
        $("#thema8").attr("checked", true);
    });

    $("#thema9").on('click', function() {
    	$(".thema").attr("checked",false);
        $(".themalabel").removeClass("active");
        $("#themalabel9").addClass("active");
        $("#thema9").attr("checked", true);
    });

    $("#thema10").on('click', function() {
    	$(".thema").attr("checked",false);
        $(".themalabel").removeClass("active");
        $("#themalabel10").addClass("active");
        $("#thema10").attr("checked", true);
    });

    $("#thema11").on('click', function() {
    	$(".thema").attr("checked",false);
        $(".themalabel").removeClass("active");
        $("#themalabel11").addClass("active");
        $("#thema11").attr("checked", true);
    });
});
